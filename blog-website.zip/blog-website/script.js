/* =========================================================
   SCRIPT.JS — the "behavior" of our blog
   ---------------------------------------------------------
   What this file does, step by step:
   1. Grab references to the HTML elements we need.
   2. Load any posts already saved in the browser (localStorage).
   3. Draw ("render") those posts onto the page.
   4. Listen for the form being submitted -> create a new post.
   5. Listen for "Delete" button clicks -> remove that post.

   KEY BEGINNER CONCEPT: "localStorage"
   Browsers give every website a small storage box called
   localStorage. It only stores TEXT, so we convert our list
   of posts (an array of objects) into a text format called
   JSON using JSON.stringify(), and convert it back with
   JSON.parse().
   ========================================================= */

// ---------- 1. GRAB HTML ELEMENTS ----------
// document.getElementById() finds an element by its "id" attribute.
const postForm = document.getElementById('post-form');
const titleInput = document.getElementById('post-title');
const contentInput = document.getElementById('post-content');
const postsContainer = document.getElementById('posts-container');
const emptyMessage = document.getElementById('empty-message');

// The key we'll use to save/load data in localStorage.
const STORAGE_KEY = 'myBlogPosts';


// ---------- 2. LOAD POSTS FROM localStorage ----------
// This function reads the saved text from localStorage and
// turns it back into a normal JavaScript array of post objects.
// If nothing is saved yet, it returns an empty array [].
function loadPosts() {
  const savedText = localStorage.getItem(STORAGE_KEY);

  if (!savedText) {
    return []; // Nothing saved yet
  }

  return JSON.parse(savedText);
}

// This function does the opposite: it takes our array of posts
// and saves it into localStorage as text.
function savePosts(posts) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(posts));
}

// Our "posts" array lives in memory while the page is open.
// We start by loading whatever was saved last time.
let posts = loadPosts();


// ---------- 3. RENDER POSTS ONTO THE PAGE ----------
// This function clears the posts container and rebuilds it
// from scratch based on the current "posts" array.
// We call this every time posts change (added or deleted).
function renderPosts() {
  // Clear out whatever is currently shown
  postsContainer.innerHTML = '';

  // Show/hide the "No posts yet" message
  if (posts.length === 0) {
    emptyMessage.classList.remove('hidden');
  } else {
    emptyMessage.classList.add('hidden');
  }

  // Loop through every post, newest first, and build a card for it.
  // slice().reverse() makes a reversed COPY so we don't change the
  // original order stored in localStorage.
  posts.slice().reverse().forEach((post) => {
    const card = document.createElement('div');
    card.className = 'post-card';

    // Using template literals (backticks) to build HTML with
    // variables plugged in via ${ }.
    card.innerHTML = `
      <h3>${escapeHTML(post.title)}</h3>
      <p class="post-date">${post.date}</p>
      <p class="post-content">${escapeHTML(post.content)}</p>
      <button class="delete-btn" data-id="${post.id}">Delete</button>
    `;

    postsContainer.appendChild(card);
  });

  // Now that the delete buttons exist in the page, wire them up.
  attachDeleteButtons();
}

// Small helper to prevent HTML tags typed by the user from being
// treated as real HTML (a basic safety habit called "escaping").
function escapeHTML(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}


// ---------- 4. HANDLE THE "PUBLISH POST" FORM ----------
// "submit" fires when the user clicks the button OR presses Enter.
postForm.addEventListener('submit', function (event) {
  // Stop the browser's default behavior, which would reload the page.
  event.preventDefault();

  const title = titleInput.value.trim();
  const content = contentInput.value.trim();

  // Simple validation — required attributes already help,
  // but this double-checks in JavaScript too.
  if (title === '' || content === '') {
    return;
  }

  // Build a new post object.
  const newPost = {
    id: Date.now(),               // a quick, unique-enough ID
    title: title,
    content: content,
    date: new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }),
  };

  // Add it to our in-memory array, save, and re-render.
  posts.push(newPost);
  savePosts(posts);
  renderPosts();

  // Clear the form so it's ready for the next post.
  postForm.reset();
});


// ---------- 5. HANDLE DELETE BUTTONS ----------
// Since delete buttons get created fresh every time we render,
// we attach their click listeners right after rendering.
function attachDeleteButtons() {
  const deleteButtons = document.querySelectorAll('.delete-btn');

  deleteButtons.forEach((button) => {
    button.addEventListener('click', function () {
      // data-id was set as a string, so we convert it to a number
      // to match the "id" stored on our post objects.
      const idToDelete = Number(button.getAttribute('data-id'));

      // Keep every post EXCEPT the one whose id matches.
      posts = posts.filter((post) => post.id !== idToDelete);

      savePosts(posts);
      renderPosts();
    });
  });
}


// ---------- INITIAL RENDER ----------
// Run this once when the page first loads, so any previously
// saved posts appear immediately.
renderPosts();
